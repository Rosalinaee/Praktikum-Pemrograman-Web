<!DOCTYPE html>
<html>
<head>
    <title>CRUD Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
 <style>
       body {
           margin: 0;
           font-family: Arial, sans-serif;
           background-image: url('/images/5.jpg');
           background-size: cover;
           background-position: center;
           background-repeat: no-repeat;
           min-height: 100vh;
       }
       .container {
           max-width: 900px;
           margin: 0 auto;
           padding: 20px;
           background: rgba(255, 255, 255, 0.75);
           border-radius: 10px;
           opacity:100% ;
       }
       table {
           width: 100%;
           border-collapse: collapse;
           background: white;
           color: black;
       }
       table th, table td {
           padding: 10px;
           border: 1px solid #ccc;
       }
       a, button {
           color: #fff;
           background-color: #007bff;
           padding: 5px 10px;
           border: none;
           border-radius: 4px;
           text-decoration: none;
       }
       a:hover, button:hover {
           background-color: #0056b3;
       }
   </style>
</head>
<body>
   <div class="container">
       @yield('content')
   </div>
</body>
</html>