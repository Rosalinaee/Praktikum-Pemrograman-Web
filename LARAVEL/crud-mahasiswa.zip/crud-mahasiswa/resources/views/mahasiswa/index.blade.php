@extends('layouts.app')

@section('content')
<div class="container mt-5 p-4 rounded shadow" style="background-color: rgba(255, 255, 255, 0.75);">

    <h2 class="mb-4 text-center text-primary fw-bold">Daftar Mahasiswa</h2>

    @if(session('success'))
        <div class="alert alert-success text-center">{{ session('success') }}</div>
    @endif

    <div class="mb-4">
        <a href="{{ route('mahasiswa.create') }}" class="btn btn-primary shadow">+ Tambah Mahasiswa</a>
    </div>

    <div class="row row-cols-1 row-cols-md-3 g-4">
        @foreach($mahasiswas as $mahasiswa)
        <div class="col">
            <div class="card h-100 shadow" style="background-color: #e0f7fa; border-left: 5px solid #29b6f6;">
                <div class="card-body">
                    <h5 class="card-title text-primary fw-bold">{{ $mahasiswa->nama }}</h5>
                    <p class="card-text">
                        <strong>NIM:</strong> {{ $mahasiswa->nim }}<br>
                        <strong>Jurusan:</strong> {{ $mahasiswa->jurusan }}<br>
                        <strong>Email:</strong> {{ $mahasiswa->email }}
                    </p>
                </div>
                <div class="card-footer bg-transparent border-0 d-flex justify-content-between">
                    <a href="{{ route('mahasiswa.show', $mahasiswa->id) }}" class="btn btn-info btn-sm">Lihat</a>
                    <a href="{{ route('mahasiswa.edit', $mahasiswa->id) }}" class="btn btn-warning btn-sm">Edit</a>
                    <form action="{{ route('mahasiswa.destroy', $mahasiswa->id) }}" method="POST" style="display: inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm"
                            onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
