@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h2 class="mb-4 text-center text-primary fw-bold">Edit Mahasiswa</h2>

    {{-- Tampilkan validasi error jika ada --}}
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    {{-- Form edit --}}
    <div class="card shadow" style="background-color: #e0f7fa; border-left: 5px solid #29b6f6;">
        <div class="card-body">
            <form action="{{ route('mahasiswa.update', $mahasiswa->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="mb-3">
                    <label class="form-label">Nama:</label>
                    <input type="text" name="nama" value="{{ $mahasiswa->nama }}" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">NIM:</label>
                    <input type="text" name="nim" value="{{ $mahasiswa->nim }}" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Jurusan:</label>
                    <input type="text" name="jurusan" value="{{ $mahasiswa->jurusan }}" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email:</label>
                    <input type="email" name="email" value="{{ $mahasiswa->email }}" class="form-control" required>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="{{ route('mahasiswa.index') }}" class="btn btn-secondary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
