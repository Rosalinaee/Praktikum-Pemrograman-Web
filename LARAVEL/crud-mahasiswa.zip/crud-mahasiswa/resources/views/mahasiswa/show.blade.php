@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h2 class="mb-4 text-center text-primary fw-bold">Detail Mahasiswa</h2>

    <div class="card shadow" style="background-color: #e0f7fa; border-left: 5px solid #29b6f6;">
        <div class="card-body">
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><strong>Nama:</strong> {{ $mahasiswa->nama }}</li>
                <li class="list-group-item"><strong>NIM:</strong> {{ $mahasiswa->nim }}</li>
                <li class="list-group-item"><strong>Jurusan:</strong> {{ $mahasiswa->jurusan }}</li>
                <li class="list-group-item"><strong>Email:</strong> {{ $mahasiswa->email }}</li>
            </ul>
        </div>
    </div>

    <div class="mt-4">
        <a href="{{ route('mahasiswa.index') }}" class="btn btn-secondary">Kembali</a>
    </div>
</div>
@endsection
