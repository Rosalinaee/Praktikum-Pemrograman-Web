

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4 text-center text-primary fw-bold">Edit Mahasiswa</h2>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <div class="card shadow" style="background-color: #e0f7fa; border-left: 5px solid #29b6f6;">
        <div class="card-body">
            <form action="<?php echo e(route('mahasiswa.update', $mahasiswa->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label">Nama:</label>
                    <input type="text" name="nama" value="<?php echo e($mahasiswa->nama); ?>" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">NIM:</label>
                    <input type="text" name="nim" value="<?php echo e($mahasiswa->nim); ?>" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Jurusan:</label>
                    <input type="text" name="jurusan" value="<?php echo e($mahasiswa->jurusan); ?>" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email:</label>
                    <input type="email" name="email" value="<?php echo e($mahasiswa->email); ?>" class="form-control" required>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-mahasiswa\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>