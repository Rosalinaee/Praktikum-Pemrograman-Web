

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4 text-center text-primary fw-bold">Detail Mahasiswa</h2>

    <div class="card shadow" style="background-color: #e0f7fa; border-left: 5px solid #29b6f6;">
        <div class="card-body">
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><strong>Nama:</strong> <?php echo e($mahasiswa->nama); ?></li>
                <li class="list-group-item"><strong>NIM:</strong> <?php echo e($mahasiswa->nim); ?></li>
                <li class="list-group-item"><strong>Jurusan:</strong> <?php echo e($mahasiswa->jurusan); ?></li>
                <li class="list-group-item"><strong>Email:</strong> <?php echo e($mahasiswa->email); ?></li>
            </ul>
        </div>
    </div>

    <div class="mt-4">
        <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-secondary">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-mahasiswa\resources\views/mahasiswa/show.blade.php ENDPATH**/ ?>